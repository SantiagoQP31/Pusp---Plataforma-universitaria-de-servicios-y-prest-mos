def mostrar_menu_estudiante():
  print("\nMenú Estudiante:")
  print("1. Realizar reserva de instalaciones/herramientas de estudio")
  print("2. Comprar comida")
  print("3. Salir")


def mostrar_menu_administrador():
  print("\nMenú Administrador:")
  print("1. Generar informes sobre el uso de las herramientas")
  print("2. Gestionar reservas realizadas por estudiantes")
  print("3. Salir")
