class Producto:

  def __init__(self, nombre, cantidad_disponible):
    self.nombre = nombre
    self.cantidad_disponible = cantidad_disponible

  